//
//  PXQuantizer.h
//  PXOpenSave
//
//  Created by Aidas Dailide on 2009-07-01.
//  Copyright 2009 Pixelmator Team Ltd.. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <Accelerate/Accelerate.h>

@interface PXQuantizer : NSObject {
	
}
-(void)quantizeRGBBuffer:(vImage_Buffer*)buffer desiredColors:(int)targetColors output:(unsigned char *)output outputMap:(unsigned char *)outputMap returnedColors:(int *)returnedColors supportAlpha:(BOOL)supportAlpha transparentIndex:(int *)transparentIndex lockedColors:(NSArray *)lockedColors ignoredColors:(NSArray *)ignoredColors;
@end
