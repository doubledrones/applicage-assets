//
//  PXSWPNGOptimizer.h
//  PXOpenSave
//
//  Created by Aidas Dailide on 2009-05-28.
//  Copyright 2009 Pixelmator Team Ltd.. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <Accelerate/Accelerate.h>

@interface PXSWPNGOptimizer : NSObject {
NSLock *_writeLock;
}
-(NSData *)writePNGBuffer:(vImage_Buffer *)imageBuffer isTransparent:(BOOL)isTransparent matteColor:(NSColor *)matteColor colorPalette:(unsigned char *)colorPalette numOfColors:(int)numOfColors transparentIndex:(int)transparentIndex;
@end
