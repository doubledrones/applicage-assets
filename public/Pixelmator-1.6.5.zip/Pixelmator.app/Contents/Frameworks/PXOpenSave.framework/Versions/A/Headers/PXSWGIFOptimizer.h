//
//  PXSWGIFOptimizer.h
//  PXOpenSave
//
//  Created by Aidas Dailide on 2009-06-25.
//  Copyright 2009 Pixelmator Team Ltd.. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import <Accelerate/Accelerate.h>
@interface PXSWGIFOptimizer : NSObject {
NSLock *_writeLock;
}
-(NSData *)writeGIFBuffer:(vImage_Buffer *)imageBuffer colorPalette:(unsigned char *)colorPalette numOfColors:(int)numOfColors transparentIndex:(int)transparentIndex;
@end
