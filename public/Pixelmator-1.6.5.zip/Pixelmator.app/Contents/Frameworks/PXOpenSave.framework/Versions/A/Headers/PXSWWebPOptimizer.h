//
//  PXSWWebPOptimizer.h
//  PXOpenSave
//
//  Created by Aidas Dailide on 10/3/10.
//  Copyright 2010 Pixelmator Team. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import <Accelerate/Accelerate.h>

@interface PXSWWebPOptimizer : NSObject {

}
+(NSData *)writeWebPFromRGBABuffer:(vImage_Buffer)sourceBuffer quality:(int)quality;
//called is responsible for releasing returned vImage_Buffer->data and vImage_Buffer itself
+(vImage_Buffer *)readRGBAFromWebPBuffer:(unsigned char *)webPData length:(int)webPLength;
@end
