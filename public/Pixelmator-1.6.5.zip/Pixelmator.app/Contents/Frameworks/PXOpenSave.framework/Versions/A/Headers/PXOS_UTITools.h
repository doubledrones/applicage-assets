//
//  PXOS_UTITools.h
//  PXOpenSave
//
//  Created by Rimas Mickevičius on 2008-08-18.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface PXOS_UTITools : NSObject
{

}

+(PXOS_UTITools*)sharedInstance;


-(BOOL)isFileSupportedAtPath:(NSString*)filePath;

-(NSString*)universalTypeForFile:(NSString*)filename;

@end
