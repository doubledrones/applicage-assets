//
//  id3Tags.h
//  id3Tag
//
//  Created by Chris Drew on Sat Nov 02 2002.
//  Copyright (c) 2002 __MyCompanyName__. All rights reserved.
//
#ifdef __APPLE__
#import <Foundation/Foundation.h>
#import "id3V2Frame.h"
#else
#ifndef _ID3FRAMEWORK_ID3V2TAG_H_
#define _ID3FRAMEWORK_ID3V2TAG_H_

#include "id3V2Frame.h"
#include <Foundation/NSObject.h>

@class NSMutableDictionary;
#endif
#endif



// Constants for defining size and location of elements within V22 and V23 headers and frames
#define IdLength	4 // length of header id characters


@interface id3V2Tag : NSObject {
    //ID3 tag header variables
    BOOL present;
    BOOL parsed;
    int majorVersion;
    int minorVersion;
    int flag;
    int tagLength;
    int paddingLength;
    int positionInFile;
    int frameSetLength;
    BOOL atStart;
    int	tagChanged;
    
    //Parsing properties
    BOOL exhastiveSearch;
    
    //storage for tag
    NSMutableDictionary *frameSet;  // stores the frame set
    NSMutableData * extendedHeader;
    
    //tag contents variables 
    int extendedHeaderPresent; // YES if Tag has an extended header
    
    // file properties
    NSString *path;
    unsigned long long fileSize;
    
    //error variables
    int errorNo;
    NSString *errorDescription;
    
    //frame dictionary 
    NSDictionary *frameSetDictionary;
}

-(id)init;
-(BOOL)openPath:(NSString *)Path frameSetDictionary:(NSDictionary *)frameSets;

// information
-(int)tagVersion;
-(BOOL)tagPresent;
-(BOOL)extendedHeader;
-(BOOL)tagUnsynch;
-(BOOL)compressTag;
-(BOOL)footer;

-(BOOL)setExtendedHeader:(BOOL)Flag;
-(BOOL)setTagUnsynch:(BOOL)Flag;
-(BOOL)setCompressTag:(BOOL)Flag;
-(BOOL)setFooter:(BOOL)Flag;

// read ID3 v2 header information
- (int)scanForHeader:(NSData *)Data;
- (BOOL)parseExtendedHeader:(NSData *)Header;
- (NSMutableData *)desynchData:(NSData *)Data offset:(int)Offset;
- (int)tagLength;
- (int)tagPositionInFile;

// id3V2 tag processing
-(BOOL)getTag;
- (int)readPackedLengthFrom:(char *)Bytes;
-(id)getFramesTitled:(NSString *)Name;
-(int)getPaddingLength;
-(NSMutableData *)renderHeader;

// id3V2 tag editing
-(BOOL)dropTag:(BOOL)NewTag;
-(BOOL)newTag:(int)MajorVersion minor:(int)MinorVersion;
-(BOOL)dropFrame:(NSString *)Name frame:(int)index;
-(BOOL)writeTag;
-(BOOL)addUpdateFrame:(id3V2Frame *)Frame replace:(BOOL)Replace frame:(int)index;
-(BOOL)setFrames:(NSMutableArray *)newFrames;
-(NSData *)writePackedLength:(int)Length;
-(void)dealloc;

// get attributes
-(NSString *)getTitle;
-(NSString *)getArtist;
-(NSString *)getAlbum;
-(int)getYear;
-(int)getTrack;
-(int)getTotalNumberDisks;
-(int)getDisk;
-(int)getTotalNumberTracks;
-(NSArray *)getGenreNames;
-(NSString *)getComments;
-(NSMutableArray *)getImage;
-(NSArray *)frameList;
-(NSString *)getEncodedBy;
-(NSString *)getComposer;

// these are private functions do not use
-(NSMutableDictionary *)getImageFrom2Frame:(id3V2Frame *)frame;
-(NSMutableDictionary *)getImageFrom3Frame:(id3V2Frame *)frame;
-(NSString *)decodeImageType:(int)encodedValue;
-(id3V2Frame *)getFirstFrameNamed:(NSString *)Name;

-(int)numberInSetString:(NSString *)Set;
-(int)setSizeInSetString:(NSString *)Set;

@end
